#!/bin/bash

rpc_client -b 10.7.4.200 -p 5182 -w io02 --timeout 15 -c 'cfgLoader -n -e'