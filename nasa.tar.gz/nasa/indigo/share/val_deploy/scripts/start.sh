#!/bin/bash

daemon_client -b 10.7.4.200 -p 5182 -w io02 -n valcontrol -d /opt/ros/indigo/bin/roslaunch -o 'val_deploy val.launch --' -c start