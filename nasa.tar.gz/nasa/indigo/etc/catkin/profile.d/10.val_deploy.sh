#!/bin/sh

if [ -z "$LUA_PATH" ]; then
    LUA_PATH=";"
fi

export LUA_PATH="/opt/nasa/indigo/share/val_deploy/scripts/?.lua;$LUA_PATH"
